-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2018 at 03:03 PM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbdpl`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(6) UNSIGNED NOT NULL,
  `acc_initial_asset` float NOT NULL,
  `acc_deposit` float NOT NULL,
  `acc_bill_credit` float NOT NULL,
  `acc_perchase_debit` float NOT NULL,
  `acc_transection_date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(6) UNSIGNED NOT NULL,
  `client_company` varchar(200) NOT NULL,
  `client_full_name` varchar(100) NOT NULL,
  `client_possition` varchar(100) NOT NULL,
  `client_depertment` varchar(100) NOT NULL,
  `client_phone_no` int(15) NOT NULL,
  `client_email` varchar(100) NOT NULL,
  `client_address_line_1` varchar(100) NOT NULL,
  `client_address_line_2` varchar(100) NOT NULL,
  `client_address_line_3` varchar(100) NOT NULL,
  `client_adding_date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `client_company`, `client_full_name`, `client_possition`, `client_depertment`, `client_phone_no`, `client_email`, `client_address_line_1`, `client_address_line_2`, `client_address_line_3`, `client_adding_date`) VALUES
(1, 'Partex Star Group', 'Mustafa Kamal', 'Dy Manager', 'Supply Chain Department', 2147483647, 'mustafa@gmail.com', 'Shantana Western Tower, Level-6', 'Bir Uttam Mir Shawkat Road, 186 Tejgoan I/A,', 'Dhaka-1208, Bangladesh', '2018-09-02 11:06:55.971606'),
(2, 'Friends It Ltd.', 'Ripa Akter', 'Manager', 'Development', 987, 'ripa@email.com', 'Jatrabari Bzsjkdhlj', '474778 Shjdhd', 'Dhaka-1204', '2018-09-02 17:49:11.624998'),
(3, 'D 16', 'Shibli Sadek', 'Dy Manager', 'Development', 2147483647, 'amh@email.com', 'Amdhfkj;', ',hgjkh', ',cgjkj', '2018-09-02 17:50:07.081351');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(6) UNSIGNED NOT NULL,
  `company_full_name` varchar(100) NOT NULL,
  `company_title` varchar(100) NOT NULL,
  `address_line_1` varchar(100) NOT NULL,
  `address_line_2` varchar(100) NOT NULL,
  `address_line_3` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `company_full_name`, `company_title`, `address_line_1`, `address_line_2`, `address_line_3`) VALUES
(1, 'divine packaging industries', 'All kinds of carton manufacturer', '26/08/A, North Perarbagh, Mirpur, Dhaka-1216', 'Phone : 8090179, Fax : 8090180', 'Mobile : 01916-791810, 01616-791810');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(6) UNSIGNED NOT NULL,
  `item_catagory_name` varchar(50) NOT NULL,
  `item_model_name` varchar(50) NOT NULL,
  `item_size` varchar(50) NOT NULL,
  `item_price` double NOT NULL,
  `item_full_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `item_catagory_name`, `item_model_name`, `item_size`, `item_price`, `item_full_name`) VALUES
(1, '5 Ply Carton', ' Model: Rsd-34-1/1', ' 1210X440X135Mm	', 88, ''),
(2, '5 Ply Carton', ' Model: Rsd-0038-1/1', ' 1060 X 410 X 160Mm ', 79, ''),
(3, '5 Ply Carton', ' Model: Rsh-P001-1/1', ' 895 X 750 X 90Mm ', 130, ''),
(4, '5 Ply Carton', ' Model: Sdp 37-1/3', ' 1810 X 465 X 40Mm ', 107, ''),
(5, '5 Ply Carton', ' Model: Sdp 37-2/3', ' 620 X 420 X 140Mm ', 57, ''),
(6, 'shibli ply', 'normal', '12X12X10', 120, '');

-- --------------------------------------------------------

--
-- Table structure for table `operations`
--

CREATE TABLE `operations` (
  `id` int(6) UNSIGNED NOT NULL,
  `item_id` int(6) DEFAULT NULL,
  `item_full_name` varchar(200) NOT NULL,
  `item_qty` int(6) NOT NULL,
  `item_price` float NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `quotation_no` varchar(10) NOT NULL,
  `work_oder_status` varchar(20) NOT NULL,
  `delivery_date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `operations`
--

INSERT INTO `operations` (`id`, `item_id`, `item_full_name`, `item_qty`, `item_price`, `client_name`, `quotation_no`, `work_oder_status`, `delivery_date`) VALUES
(1, 1, '5 Ply Carton, Model: Rsd-34-1/1, Model: Rsd-34-1/1, Size: 1210X440X135Mm', 60, 88, 'Partex Star Group', '1', 'pending', '2018-09-04 06:40:16.865522'),
(2, 2, '5 Ply Carton, Model: Rsd-0038-1/1, Model: Rsd-0038-1/1, Size: 1060 X 410 X 160Mm', 60, 79, 'Partex Star Group', '1', 'pending', '2018-09-04 06:40:16.928011'),
(3, 5, '5 Ply Carton, Model: Sdp 37-2/3, Model: Sdp 37-2/3, Size: 620 X 420 X 140Mm', 60, 57, 'Partex Star Group', '1', 'pending', '2018-09-04 06:40:16.974885'),
(4, 2, '5 Ply Carton, Model: Rsd-0038-1/1, Model: Rsd-0038-1/1, Size: 1060 X 410 X 160Mm', 60, 79, 'Partex Star Group', '2', 'pending', '2018-09-04 06:40:24.630651'),
(5, 3, '5 Ply Carton, Model: Rsh-P001-1/1, Model: Rsh-P001-1/1, Size: 895 X 750 X 90Mm', 60, 130, 'Partex Star Group', '2', 'pending', '2018-09-04 06:40:24.693149'),
(6, 4, '5 Ply Carton, Model: Sdp 37-1/3, Model: Sdp 37-1/3, Size: 1810 X 465 X 40Mm', 60, 107, 'Partex Star Group', '2', 'pending', '2018-09-04 06:40:24.740020'),
(7, 5, '5 Ply Carton, Model: Sdp 37-2/3, Model: Sdp 37-2/3, Size: 620 X 420 X 140Mm', 60, 57, 'Partex Star Group', '2', 'pending', '2018-09-04 06:40:24.771269'),
(8, 2, '5 Ply Carton, Model: Rsd-0038-1/1, Model: Rsd-0038-1/1, Size: 1060 X 410 X 160Mm', 60, 79, 'Partex Star Group', '3', 'pending', '2018-09-04 06:40:32.473844'),
(9, 3, '5 Ply Carton, Model: Rsh-P001-1/1, Model: Rsh-P001-1/1, Size: 895 X 750 X 90Mm', 60, 130, 'Partex Star Group', '3', 'pending', '2018-09-04 06:40:32.520724'),
(10, 4, '5 Ply Carton, Model: Sdp 37-1/3, Model: Sdp 37-1/3, Size: 1810 X 465 X 40Mm', 60, 107, 'Partex Star Group', '3', 'pending', '2018-09-04 06:40:32.583224'),
(11, 1, '5 Ply Carton, Model: Rsd-34-1/1, Model: Rsd-34-1/1, Size: 1210X440X135Mm', 60, 88, 'Friends It Ltd.', '4', 'delivered', '2018-09-04 06:47:16.119715'),
(12, 2, '5 Ply Carton, Model: Rsd-0038-1/1, Model: Rsd-0038-1/1, Size: 1060 X 410 X 160Mm', 60, 79, 'Friends It Ltd.', '4', 'delivered', '2018-09-04 06:47:16.182214'),
(13, 4, '5 Ply Carton, Model: Sdp 37-1/3, Model: Sdp 37-1/3, Size: 1810 X 465 X 40Mm', 60, 107, 'Friends It Ltd.', '4', 'delivered', '2018-09-04 06:47:16.229087'),
(14, 5, '5 Ply Carton, Model: Sdp 37-2/3, Model: Sdp 37-2/3, Size: 620 X 420 X 140Mm', 60, 57, 'Friends It Ltd.', '4', 'delivered', '2018-09-04 06:47:16.275947'),
(15, 2, '5 Ply Carton, Model: Rsd-0038-1/1, Model: Rsd-0038-1/1, Size: 1060 X 410 X 160Mm', 60, 79, 'D 16', '5', 'delivered', '2018-09-04 06:41:43.531927'),
(16, 3, '5 Ply Carton, Model: Rsh-P001-1/1, Model: Rsh-P001-1/1, Size: 895 X 750 X 90Mm', 60, 130, 'D 16', '5', 'delivered', '2018-09-04 06:41:43.578802'),
(17, 4, '5 Ply Carton, Model: Sdp 37-1/3, Model: Sdp 37-1/3, Size: 1810 X 465 X 40Mm', 60, 107, 'D 16', '5', 'delivered', '2018-09-04 06:41:43.641291'),
(18, 5, '5 Ply Carton, Model: Sdp 37-2/3, Model: Sdp 37-2/3, Size: 620 X 420 X 140Mm', 60, 57, 'D 16', '5', 'delivered', '2018-09-04 06:41:43.688171'),
(19, 1, '5 Ply Carton, Model: Rsd-34-1/1, Model: Rsd-34-1/1, Size: 1210X440X135Mm', 10, 1000, 'D 16', '6', 'delivered', '2018-09-04 06:55:23.994061'),
(20, 2, '5 Ply Carton, Model: Rsd-0038-1/1, Model: Rsd-0038-1/1, Size: 1060 X 410 X 160Mm', 20, 2000, 'D 16', '6', 'delivered', '2018-09-04 06:55:24.040947'),
(21, 3, '5 Ply Carton, Model: Rsh-P001-1/1, Model: Rsh-P001-1/1, Size: 895 X 750 X 90Mm', 30, 3000, 'D 16', '6', 'delivered', '2018-09-04 06:55:24.087818'),
(22, 4, '5 Ply Carton, Model: Sdp 37-1/3, Model: Sdp 37-1/3, Size: 1810 X 465 X 40Mm', 40, 3990, 'D 16', '6', 'delivered', '2018-09-04 06:55:24.134689'),
(23, 5, '5 Ply Carton, Model: Sdp 37-2/3, Model: Sdp 37-2/3, Size: 620 X 420 X 140Mm', 50, 5000, 'D 16', '6', 'delivered', '2018-09-04 06:55:24.165926'),
(24, 1, '5 Ply Carton, Model: Rsd-34-1/1, Model: Rsd-34-1/1, Size: 1210X440X135Mm', 600, 10, 'D 16', '7', 'delivered', '2018-09-04 09:37:58.542269'),
(25, 2, '5 Ply Carton, Model: Rsd-0038-1/1, Model: Rsd-0038-1/1, Size: 1060 X 410 X 160Mm', 60, 79, 'D 16', '7', 'delivered', '2018-09-04 09:37:58.589151'),
(26, 3, '5 Ply Carton, Model: Rsh-P001-1/1, Model: Rsh-P001-1/1, Size: 895 X 750 X 90Mm', 60, 130, 'D 16', '7', 'delivered', '2018-09-04 09:37:58.636023'),
(27, 2, '5 Ply Carton, Model: Rsd-0038-1/1, Model: Rsd-0038-1/1, Size: 1060 X 410 X 160Mm', 100, 79, 'Partex Star Group', '8', 'pending', '2018-09-04 09:40:21.438750'),
(28, 3, '5 Ply Carton, Model: Rsh-P001-1/1, Model: Rsh-P001-1/1, Size: 895 X 750 X 90Mm', 100, 130, 'Partex Star Group', '8', 'pending', '2018-09-04 09:40:21.501258'),
(29, 1, '5 Ply Carton, Model: Rsd-34-1/1, Model: Rsd-34-1/1, Size: 1210X440X135Mm', 60, 88, 'D 16', '9', 'delivered', '2018-09-04 09:46:11.124719'),
(30, 2, '5 Ply Carton, Model: Rsd-0038-1/1, Model: Rsd-0038-1/1, Size: 1060 X 410 X 160Mm', 60, 79, 'D 16', '9', 'delivered', '2018-09-04 09:46:11.187218'),
(31, 3, '5 Ply Carton, Model: Rsh-P001-1/1, Model: Rsh-P001-1/1, Size: 895 X 750 X 90Mm', 60, 130, 'D 16', '9', 'delivered', '2018-09-04 09:46:11.218466');

-- --------------------------------------------------------

--
-- Table structure for table `perchases`
--

CREATE TABLE `perchases` (
  `id` int(6) UNSIGNED NOT NULL,
  `parchase_item_name` varchar(50) NOT NULL,
  `parchase_item_model_name` varchar(50) NOT NULL,
  `parchase_item_qty` varchar(50) NOT NULL,
  `parchase_item_price` varchar(255) NOT NULL,
  `parchase_date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(6) UNSIGNED NOT NULL,
  `user_full_name` varchar(30) NOT NULL,
  `user_username` varchar(30) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user_full_name`, `user_username`, `user_password`, `user_status`) VALUES
(1, 'Shibli Sadek', 'shibli', '$2y$10$pN8ePLpBzdJjHcKvfjgjQeXHpkSn608eMVZCp7Yn8pRYk7wEmpUKe', 'admin'),
(2, 'nurul huda', 'admin', '$2y$10$N4YVphjWoqQoSznrMrdYaOtURd9TSW9ck/UrQ3/PvaUwF5sNFzJnu', 'admin'),
(3, 'md rashid', 'rashid', '$2y$10$tnM5dhRc54YSFyhtfyiPOO7K.e8vZ3.h8FO5SJx4SywNLgau8QQr6', 'employee');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `operations`
--
ALTER TABLE `operations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `perchases`
--
ALTER TABLE `perchases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `operations`
--
ALTER TABLE `operations`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `perchases`
--
ALTER TABLE `perchases`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
